"use client"

import LocationTracker from "../location-tracker"

export default function Page() {
  return <LocationTracker />
}
